#include <stdio.h>
void exchange(int *u,int *v)//交换函数，用于交换u和v的数值
{
	int temp;
	temp = *u;
	*u = *v;
	*v = temp;
}

void HeapAdjust(int Cost[],int begin,int end)//调整函数 把begin~end的元素调整为大顶堆
{
	int temp = Cost[begin];
	int parent = begin;
	int child;
	while(2*parent <= end)//2*parent为parent的左孩子
	{
        	child = 2*parent;//2*parent为parent的左孩子
		if(child != end && Cost[child] < Cost[child + 1])
			child++;
		if(temp > Cost[child])//根结点>左右孩子中的Cost最大值
			break;
		if(temp <= Cost[child])
			Cost[parent] = Cost[child];
		parent = child;
	}
	Cost[parent] = temp;
}

void HeapSort(int Cost[],int n)//堆排序函数
{
	for(int i = n/2; i >= 1; i--)
		HeapAdjust(Cost,i,n);
	for(int i = n; i >= 1; i--)
	{
		exchange(&Cost[1] , &Cost[i]);//两个的值进行交换
		HeapAdjust(Cost, 1, i-1);
	}
}

int main()
{
	int n;
	printf("Input the number of roads\n");
	scanf("%d", &n);
	int Cost[n+1];
	for(int i=1; i<=n; i++)
	{
    	printf("Input cost of road %d\n",i);
		scanf("%d", &Cost[i]);
	}
	HeapSort(Cost, n);
	printf("Sorted Cost:");
	for(int i=1; i<=n; i++)
		printf(" %d",Cost[i]);
	printf("\n");
	return 0;
}
