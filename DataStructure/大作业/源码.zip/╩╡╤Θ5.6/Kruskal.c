#include<stdio.h>

#define MAXEDGE 100		//图中最大边数
#define MAXVEX	30		//图中最大顶点数
typedef char VertexType;//输入顶点的类型

typedef struct
{
	VertexType begin;	//作为起点的顶点
	VertexType end;		//作为终点的顶点
	int cost;			//边的权值，表示路线花费
}VNode;					//存储边（带权）的数组

typedef struct
{
	int ver_num;		//顶点的数量
	int edge_num;		//边的数量
	VNode node[MAXEDGE]; //存储边（带权）的数组
}Graph;					//图的类型

void Init_Graph(Graph &S);//初始化图，将城市的数据录入图中
void sort(Graph &S);//依据边的权值对不同的VNode存储数组进行从小到大的冒泡排序
int FindParent(int parent[], int c);//寻找顶点的根结点，用来判断标记的顶点是否成环
void Kruskal(Graph &S);//利用克鲁斯卡尔算法输出结果



void Init_Graph(Graph &S) //初始化图，将城市的数据录入图中
{
	VertexType a[S.edge_num], b[S.edge_num];//用来记录用户输入的顶点，a为起点，b为终点
	
	printf("Input number of vertexs:\n");//读取顶点数
	scanf("%d", &S.ver_num);
	
	printf("Input number of edges:\n");//读取边数
	scanf("%d", &S.edge_num);
	
	printf("Input every two adjacent vertexs and cost between them:\n");
	
	for(int i = 0; i < S.edge_num; i++)//读取图的初始信息
	{
		scanf("%s %s %d", &a[i], &b[i], &S.node[i].cost);
		S.node[i].begin = a[i] - 'a' + 1;//将顶点转换成数字，便于排序，对小写字母表按照从1到26的编号
		S.node[i].end = b[i] - 'a' + 1;//同上
	}
	
}//Init_Graph




void sort(Graph &S) //依据边的权值对S中不同的VNode存储数组进行从小到大的冒泡排序
{
	int i, j, t1, t2, t3;
	for(i = 0; i < S.edge_num - 1; i++)
		for(j = 0; j < S.edge_num - i - 1; j++)
			if(S.node[j].cost > S.node[j + 1].cost)
			{
				t1 = S.node[j].begin;
				t2 = S.node[j].end;
				t3 = S.node[j].cost;
				S.node[j].begin = S.node[j + 1].begin;
				S.node[j].end = S.node[j + 1].end;
				S.node[j].cost = S.node[j + 1].cost;
				S.node[j + 1].begin = t1;
				S.node[j + 1].end = t2;
				S.node[j + 1].cost = t3;
			}
}



int FindParent(int parent[], int c) //寻找顶点的根结点，用来判断标记的顶点是否成环
{
  while (parent[c] != c)
		c = parent[c];
	return c;//返回根结点
}



void Kruskal(Graph &S) //利用克鲁斯卡尔算法输出结果
{
	int i, j;
	int parent[MAXVEX];
	
	for(i = 1; i <= S.ver_num; i++) //将每个顶点的根结点初始化为它自己
		parent[i] = i;
	
	printf("The roads of the node with lowest cost are:\n");
	
	for(i = 0; i < S.edge_num; i++)
	{
		if(FindParent(parent, S.node[i].begin) != FindParent(parent, S.node[i].end))//两个结点的根结点不同
		{
			printf("<%c, %c> %d\n", S.node[i].begin - 1 + 'a', S.node[i].end - 1 + 'a', S.node[i].cost);//输出可连通的路
			parent[FindParent(parent, S.node[i].begin)] = FindParent(parent, S.node[i].end);//将起点的根结点的根结点赋值为终点的根结点
		}
	}
}

int main()//主函数
{
	Graph S;
	Init_Graph(S);//初始化图，将城市的数据录入图中
	sort(S);//冒泡排序
	Kruskal(S);//利用克鲁斯卡尔算法输出结果
	return 0;
}
